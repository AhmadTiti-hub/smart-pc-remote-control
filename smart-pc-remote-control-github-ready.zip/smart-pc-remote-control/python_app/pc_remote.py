# PC Remote Control 
import time
import threading
import tkinter
from tkinter import ttk
from tkinter import *
import serial
import win32api
import pyautogui
import os
import subprocess
import serial.tools.list_ports
ports=serial.tools.list_ports.comports()
print ("list of COM ports: \n")
for port, desc,hwid in sorted(ports):
    print("{}: {} ".format(port, desc))

# code assembled and edited by Ahmad Titi

serial_data = ''
filter_data = ''
update_period = 5
serial_object = None
gui = Tk()
gui.title("PC Remote Control")
gui.configure(background="blue")

def connect():
    global serial_object
    port = port_entry.get()
    baud = 115200 # baud_entry.get()
    try:
        serial_object = serial.Serial('COM'+ str(port), baud)
    except ValueError:
        print ("Enter Baud and Port")
        return
    t1 = threading.Thread(target = get_data)
    t1.daemon = True
    t1.start()

def get_data():
    """This function serves the purpose of collecting data from the serial object and storing 
    the filtered data into a global variable.

    The function has been put into a thread since the serial event is a blocking function.
    """
    global serial_object
    global filter_data

    while(1):   
        try:
            serial_data = serial_object.readline()
            refined=str(serial_data.decode('ascii'))
            
            serial_data=refined
           
            text.insert(END, serial_data)
            if '20DF40BF' in serial_data:
                pyautogui.press('volumeup',10)
            elif '20DFC03F' in serial_data:
                pyautogui.press('volumedown',10)
            elif '20DF906F' in serial_data:
                pyautogui.press('volumemute')
            elif '20DF00FF' in serial_data:
                pyautogui.press('pageup')
            elif '20DF807F' in serial_data:
                pyautogui.press('pagedown')
            elif '180BD9FF' in serial_data:
                pyautogui.press('win')
            elif '20DFCA35' in serial_data:
                pyautogui.rightClick()
            elif '20DF22DD' in serial_data:
                pyautogui.click()
            elif '20DF02FD' in serial_data:
                pyautogui.press('up')
            elif '20DF827D' in serial_data:
                pyautogui.press('down')
            elif '20DFE01F' in serial_data:
                pyautogui.press('left')
            elif '20DF609F' in serial_data:
                pyautogui.press('right')
            elif '20DF7887' in serial_data:
                pyautogui.press('space')
            elif '20DF14EB' in serial_data:
                pyautogui.press('backspace')
            elif '20DF8877' in serial_data:  
                pyautogui.hotkey('ctrl', 'a')
            elif '20DF48B7' in serial_data:  
                pyautogui.hotkey('ctrl', 'c') 
            elif '20DFC837' in serial_data:  
                pyautogui.hotkey('ctrl', 'v')
            elif '20DF28D7' in serial_data: 
                pyautogui.hotkey('ctrl', 'x')
            elif '20DFA857' in serial_data: 
                pyautogui.hotkey('ctrl', 'z')
            elif '20DF6897' in serial_data: 
                pyautogui.press('delete')
            elif '20DFE817' in serial_data: 
               pyautogui.press('capslock')
            elif '20DF18E7' in serial_data:
              pyautogui.hotkey('win', 'r')
            elif '20DF9867' in serial_data:
              pyautogui.hotkey('win', 's')
            elif '20DF08F7' in serial_data: 
                pyautogui.press('enter')
            elif '20DF7E81' in serial_data:
                pyautogui.hotkey('win','d')
            elif '20DFDA25' in serial_data:
                pyautogui.hotkey('alt','F4')
            elif '20DFC23D' in serial_data:
                pyautogui.press('win')
            elif '20DF10EF' in serial_data:
                subprocess.call(["shutdown", "/s"])
            elif '20DF6A95' in serial_data:
                win32api.ShellExecute(0, 'open', 'C:\Program Files\Google\Chrome\Application\\Netflix.html', '', '', 1)
            elif '20DF3AC5' in serial_data:
                win32api.ShellExecute(0, 'open', 'C:\Program Files\Google\Chrome\Application\Shahid.html', '', '', 1)
            elif '20DFD52A' in serial_data:
                win32api.ShellExecute(0, 'open', 'C:\Program Files\Google\Chrome\Application\YouTube.html', '', '', 1)
            elif '20DFC639' in serial_data:
                win32api.ShellExecute(0, 'open', 'C:\Program Files\Google\Chrome\Application\chrome.exe', '', '', 1)
            

            
                
        except TypeError:
            pass

   
        
def update_gui():
    """" This function is an update function which is also threaded. The function assimilates the data
    and applies it to it corresponding progress bar. The text box is also updated every couple of seconds.

    A simple auto refresh function .after() could have been used, this has been avoid purposely due to 
    various performance issues.
    """
    global filter_data
    global update_period
    global serial_object
    
    text.place(x = 12, y = 170)
    new = time.time()
        
    while(1):
        if time.time() - new >= update_period:
            text.delete(0.0, END)
            new = time.time()

def send():
    """This function is for sending data from the computer to the host controller.
       The value entered in the the entry box is pushed to the UART. The data can be of any format, since
        the data is always converted into ASCII, the receiving device has to convert the data into the required f
        format.
    """
    send_data = data_entry.get()
    if not send_data:
        print ("Sent Nothing")
    serial_object.write((send_data))

def disconnect():
    """ 
    This function is for disconnecting and quitting the application.

    Sometimes the application throws a couple of errors while it is being shut down, the fix isn't out yet
    but will be pushed to the repo once done.

    simple GUI.quit() calls.

    """
    try:
        serial_object.close() 
    except AttributeError:
        print ("Closed without Using it -_-")
    gui.destroy()
    gui.quit()
##########################################################################################################
if __name__ == "__main__":

    """
    The main loop consists of all the GUI objects and its placement.

    The Main loop handles all the widget placements.

    """
##    global serial_data
    #frames
    frame_1 = Frame(height = 285, width = 480, bd = 3, relief = 'groove').place(x = 7, y = 5)
    frame_2 = Frame(height = 150, width = 480, bd = 3, relief = 'groove').place(x = 7, y = 300)
    text = Text(width = 58, height = 7)#17
#threads
    t2 = threading.Thread(target = update_gui)
    t2.daemon = True
    t2.start()
# labels
    heading=Label(text="           PC REMOTE CONTROL",font="Times 25 bold italic ").place(x=12, y=10)
    heading10=Label(text="            ",font="Times 15 bold ").place(x=120, y=50)
    #baud   = Label(text = "Baud").place(x = 100, y = 348)
    port   = Label(text = "Port").place(x = 200, y = 348)
    received=Label(text="Received Serial data:",font="Times 15 ").place(x=12, y=140)
    contact = Label(text = "Designed by \n                ahmadtheotherside@gmail.com                                  ",font="Tahoma 9 bold ").place(x =8 , y = 450)
# data input   
    #baud_entry = Entry(width = 7)
    #baud_entry.place(x = 100, y = 365)
    
    port_entry = Entry(width = 7)
    port_entry.place(x = 200, y = 365)
#commands
    connect = Button(text = "Connect", command = connect).place(x = 15, y = 360)
    disconnect = Button(text = "Exit", command = disconnect,width=17).place(x =300, y = 360)
#mainloops   
    gui.geometry('500x500')
    gui.mainloop()
