Python desktop application that reads IR codes over serial and executes Windows actions.
