/*
 * IR Remote Receiver Demo
 * Reads IR codes from a VS1838B IR receiver connected to Arduino Nano.
 */

#include <IRremote.h>

int RECV_PIN = 4;

IRrecv irrecv(RECV_PIN);
decode_results results;

void setup() {
  pinMode(3, OUTPUT);
  digitalWrite(3, LOW);   // GND
  pinMode(2, OUTPUT);
  digitalWrite(2, HIGH);  // VCC

  Serial.begin(115200);

  Serial.println("Enabling IRin");
  irrecv.enableIRIn();
  Serial.println("Enabled IRin");
}

void loop() {
  if (irrecv.decode(&results)) {
    Serial.println(results.value, HEX);
    irrecv.resume();
  }
  delay(10);
}
