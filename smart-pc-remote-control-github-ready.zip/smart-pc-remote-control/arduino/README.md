Arduino sketches for the IR receiver and the BLE air mouse.
